<?php

class pluginCustomFieldsParser extends Plugin {

	public function init()
	{
		$this->dbFields = array(
			'label'=>'Custom fields parser',
			'jsondb'=>json_encode(array())
		);
	}

	public function form()
	{
		global $L;
		global $site;

		$html  = '<div class="alert alert-primary" role="alert">';
		$html .= $this->description();
		$html .= '</div>';

		$jsondb = $this->getValue('jsondb', false);
		$database = json_decode($jsondb, true);

		$customFields = $site->customFields();

		foreach ($customFields as $field=>$options) {
			if ($options['type']=="string") {
				$html .= '<div>';
				$html .= '<label>'.$options['label'].'</label>';
				$html .= '<textarea name="'.$field.'">'.(isset($database[$field])?$database[$field]:'').'</textarea>';
				$html .= '</div>';
			}
		}

		return $html;
	}

	public function post()
	{
		$this->db['jsondb'] = Sanitize::html(json_encode($_POST));
		return $this->save();
	}

	public function parse($page)
	{
		$jsondb = $this->getValue('jsondb', false);
		$database = json_decode($jsondb, true);
		$parsedCode = array();

		// Ensure $database is a valid array before iterating
		if (is_array($database)) {
			foreach ($database as $field=>$code) {
				$value = $page->custom($field);
				$parsedCode['{{ '.$field.' }}'] = str_replace('{{ value }}', $value, $code);
			}
		}

		$content = $page->contentRaw();
		if (!empty($parsedCode)) {
			$content = str_replace(array_keys($parsedCode), array_values($parsedCode), $content);
		}

		// Parse Markdown
		if (MARKDOWN_PARSER) {
			$parsedown = new Parsedown();
			$content = $parsedown->text($content);
		}

		// Parse img src relative to absolute (with domain)
		if (IMAGE_RELATIVE_TO_ABSOLUTE) {
			$domain = IMAGE_RESTRICT ? DOMAIN_UPLOADS_PAGES . $page->uuid() . '/' : DOMAIN_UPLOADS;
			$content = Text::imgRel2Abs($content, $domain);
		}

		return $content;
	}

	public function beforeSiteLoad()
	{
		if ($GLOBALS['WHERE_AM_I']=='page') {
			$GLOBALS['page']->setField('content', $this->parse($GLOBALS['page']));
		} else {
			foreach ($GLOBALS['content'] as $key=>$page)  {
				$GLOBALS['content'][$key]->setField('content', $this->parse($GLOBALS['content'][$key]));
			}
			if (!empty($GLOBALS['content'])) {
				$GLOBALS['page'] = $GLOBALS['content'][0];
			}
		}
	}
}
