<?php defined('BLUDIT') or die('Bludit CMS.');
header('Content-Type: application/json');

/*
| Upload an image to a particular page
|
| @_POST['uuid']	string	Page uuid
|
| @return		array
*/

// $_POST
// ----------------------------------------------------------------------------
$uuid = empty($_POST['uuid']) ? false : $_POST['uuid'];
// ----------------------------------------------------------------------------

// Check path traversal on $uuid
if ($uuid) {
	if (Text::stringContains($uuid, DS, false)) {
		$message = 'Path traversal detected.';
		Log::set($message, LOG_TYPE_ERROR);
		ajaxResponse(1, $message);
	}
}

// Set upload directory
if ($uuid && IMAGE_RESTRICT) {
	$imageDirectory = PATH_UPLOADS_PAGES . $uuid . DS;
	$thumbnailDirectory = $imageDirectory . 'thumbnails' . DS;
	if (!Filesystem::directoryExists($thumbnailDirectory)) {
		Filesystem::mkdir($thumbnailDirectory, true);
	}
} else {
	$imageDirectory = PATH_UPLOADS;
	$thumbnailDirectory = PATH_UPLOADS_THUMBNAILS;
}

$images = array();
foreach ($_FILES['images']['name'] as $uuid => $filename) {
	// Check for errors
	if ($_FILES['images']['error'][$uuid] != 0) {
		$message = $L->g('Maximum load file size allowed:') . ' ' . ini_get('upload_max_filesize');
		Log::set($message, LOG_TYPE_ERROR);
		ajaxResponse(1, $message);
	}

	// Convert URL characters such as spaces or quotes to characters
	$filename = urldecode($filename);
	
	// Sanitize filename to prevent issues with special characters
	$filenameWithoutExt = Filesystem::filename($filename);
	$filenameWithoutExt = Text::removeSpecialCharacters($filenameWithoutExt, '-');
	$filenameWithoutExt = Text::removeQuotes($filenameWithoutExt);
	$filenameWithoutExt = Text::removeSpaces($filenameWithoutExt, '-');
	$fileExtension = Filesystem::extension($filename);
	$filename = $filenameWithoutExt . '.' . $fileExtension;

	// Block dotfiles
	if (strpos($filename, '.') === 0) {
		$message = 'File type not allowed.';
		Log::set($message, LOG_TYPE_ERROR);
		ajaxResponse(1, $message);
	}

	// Check path traversal on $filename
	if (Text::stringContains($filename, DS, false)) {
		$message = 'Path traversal detected.';
		Log::set($message, LOG_TYPE_ERROR);
		ajaxResponse(1, $message);
	}

	// Check file extension
	$fileExtension = Filesystem::extension($filename);
	$fileExtension = Text::lowercase($fileExtension);
	if (!in_array($fileExtension, $GLOBALS['ALLOWED_IMG_EXTENSION'])) {
		$message = $L->g('File type is not supported. Allowed types:') . ' ' . implode(', ', $GLOBALS['ALLOWED_IMG_EXTENSION']);
		Log::set($message, LOG_TYPE_ERROR);
		ajaxResponse(1, $message);
	}

	// Check file MIME Type
	$fileMimeType = Filesystem::mimeType($_FILES['images']['tmp_name'][$uuid]);
	if ($fileMimeType === false) {
		$message = $L->g('File mime type is not supported. Allowed types:') . ' ' . implode(', ', $GLOBALS['ALLOWED_IMG_MIMETYPES']);
		Log::set($message, LOG_TYPE_ERROR);
		ajaxResponse(1, $message);
	}
	if (!in_array($fileMimeType, $GLOBALS['ALLOWED_IMG_MIMETYPES'])) {
		$message = $L->g('File mime type is not supported. Allowed types:') . ' ' . implode(', ', $GLOBALS['ALLOWED_IMG_MIMETYPES']);
		Log::set($message, LOG_TYPE_ERROR);
		ajaxResponse(1, $message);
	}

	// Ensure Bludit tmp directory exists
	if (!Filesystem::directoryExists(PATH_TMP)) {
		if (!Filesystem::mkdir(PATH_TMP, true)) {
			$message = 'Temporary directory does not exist and cannot be created.';
			Log::set($message, LOG_TYPE_ERROR);
			ajaxResponse(1, $message);
		}
	}

	// Move from PHP tmp file to Bludit tmp directory
	$moved = Filesystem::mv($_FILES['images']['tmp_name'][$uuid], PATH_TMP . $filename);
	if (!$moved) {
		$message = 'Error moving uploaded file to temporary directory.';
		Log::set($message, LOG_TYPE_ERROR);
		ajaxResponse(1, $message);
	}

	// Transform the image and generate the thumbnail
	$image = transformImage(PATH_TMP . $filename, $imageDirectory, $thumbnailDirectory);

	if ($image) {
		chmod($image, 0644);
		$filename = Filesystem::filename($image);
		array_push($images, $filename);
	} else {
		$message = 'Error after transformImage() function.';
		Log::set($message, LOG_TYPE_ERROR);
		ajaxResponse(1, $message);
	}
}

ajaxResponse(0, 'Images uploaded.', array(
	'images' => $images
));
